export interface IErrors {
	source: string;
	schema: string;
}
