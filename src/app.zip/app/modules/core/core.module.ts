import { NgModule } from '@angular/core';
import UtilitiesService from '../../services/utilities.service';


@NgModule({
	providers: [
		UtilitiesService
	]
})

export class CoreModule {}